import React, { useState, useEffect } from 'react';
import { Calendar, MapPin, Car, Wallet, Tag, Headset, Download, Phone, Mail, Facebook, Twitter, Instagram, ChevronUp } from 'lucide-react';

function App() {
  const [pickupDate, setPickupDate] = useState('');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  // Handle scroll events
  useEffect(() => {
    const handleScroll = () => {
      // For navbar background change
      setScrolled(window.scrollY > 50);
      
      // For scroll to top button
      setShowScrollTop(window.scrollY > 500);
      
      // For active section highlighting
      const sections = ['home', 'rent', 'service', 'why-choose-us', 'ride', 'testimonials', 'contact'];
      
      for (const section of sections.reverse()) {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          if (rect.top <= 100) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Scroll to top function
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  // Close mobile menu when clicking a link
  const handleNavLinkClick = (sectionId) => {
    setMobileMenuOpen(false);
    setActiveSection(sectionId);
    
    // Smooth scroll to section
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      {/* Navigation */}
      <header className={`${scrolled ? 'bg-blue-900 shadow-lg' : 'bg-gradient-to-r from-blue-900 to-blue-700'} text-white sticky top-0 z-50 transition-all duration-300`}>
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16 items-center">
            <div className="flex-shrink-0 flex items-center">
              <Car className={`h-8 w-8 mr-2 ${scrolled ? 'text-blue-300' : 'text-white'} transition-colors duration-300`} />
              <span className="font-bold text-2xl tracking-tight">WeCars</span>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-white hover:bg-blue-800 focus:outline-none transition-colors duration-200"
                aria-expanded={mobileMenuOpen}
              >
                <span className="sr-only">Open main menu</span>
                <svg className="h-6 w-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={mobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
                </svg>
              </button>
            </div>
            
            {/* Desktop menu */}
            <div className="hidden md:flex md:items-center md:space-x-6">
              <a 
                href="#home" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('home'); }}
                className={`${activeSection === 'home' ? 'text-blue-200 border-b-2 border-blue-300' : 'text-white hover:text-blue-200'} px-3 py-2 text-sm font-medium transition-all duration-200`}
              >
                Home
              </a>
              <a 
                href="#rent" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('rent'); }}
                className={`${activeSection === 'rent' ? 'text-blue-200 border-b-2 border-blue-300' : 'text-white hover:text-blue-200'} px-3 py-2 text-sm font-medium transition-all duration-200`}
              >
                Customers
              </a>
              <a 
                href="#service" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('service'); }}
                className={`${activeSection === 'service' ? 'text-blue-200 border-b-2 border-blue-300' : 'text-white hover:text-blue-200'} px-3 py-2 text-sm font-medium transition-all duration-200`}
              >
                Services
              </a>
              <a 
                href="#ride" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('ride'); }}
                className={`${activeSection === 'ride' ? 'text-blue-200 border-b-2 border-blue-300' : 'text-white hover:text-blue-200'} px-3 py-2 text-sm font-medium transition-all duration-200`}
              >
                Our Past
              </a>
              <a 
                href="#contact" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('contact'); }}
                className={`${activeSection === 'contact' ? 'text-blue-200 border-b-2 border-blue-300' : 'text-white hover:text-blue-200'} px-3 py-2 text-sm font-medium transition-all duration-200`}
              >
                Contact
              </a>
              <a 
                href="#" 
                className="text-white bg-blue-600 hover:bg-blue-500 px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 hover:scale-105 shadow-md hover:shadow-lg"
              >
                Sign Up
              </a>
              <a 
                href="#" 
                className="text-white bg-transparent border border-white hover:bg-blue-800 px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 hover:scale-105 ml-2"
              >
                Sign In
              </a>
              <div className="ml-2 bg-white rounded-full p-1 shadow-md hover:shadow-lg transition-all duration-200 hover:scale-105 cursor-pointer">
                <svg className="h-6 w-6 text-blue-800" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
                </svg>
              </div>
            </div>
          </div>
          
          {/* Mobile menu */}
          <div 
            className={`${mobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'} md:hidden overflow-hidden transition-all duration-300 ease-in-out`}
          >
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              <a 
                href="#home" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('home'); }}
                className={`${activeSection === 'home' ? 'bg-blue-800 text-white' : 'text-white hover:bg-blue-800'} block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                Home
              </a>
              <a 
                href="#rent" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('rent'); }}
                className={`${activeSection === 'rent' ? 'bg-blue-800 text-white' : 'text-white hover:bg-blue-800'} block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                Customers
              </a>
              <a 
                href="#service" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('service'); }}
                className={`${activeSection === 'service' ? 'bg-blue-800 text-white' : 'text-white hover:bg-blue-800'} block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                Services
              </a>
              <a 
                href="#ride" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('ride'); }}
                className={`${activeSection === 'ride' ? 'bg-blue-800 text-white' : 'text-white hover:bg-blue-800'} block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                Our Past
              </a>
              <a 
                href="#contact" 
                onClick={(e) => { e.preventDefault(); handleNavLinkClick('contact'); }}
                className={`${activeSection === 'contact' ? 'bg-blue-800 text-white' : 'text-white hover:bg-blue-800'} block px-3 py-2 rounded-md text-base font-medium transition-colors duration-200`}
              >
                Contact
              </a>
              <a 
                href="#" 
                className="text-white bg-blue-600 hover:bg-blue-500 block px-3 py-2 rounded-md text-base font-medium mt-4 transition-colors duration-200"
              >
                Sign Up
              </a>
              <a 
                href="#" 
                className="text-white bg-transparent border border-white hover:bg-blue-800 block px-3 py-2 rounded-md text-base font-medium mt-2 transition-colors duration-200"
              >
                Sign In
              </a>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section id="home" className="relative">
        <div className="relative h-[70vh] sm:h-[80vh] overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80" 
            alt="Luxury Car" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-blue-900/70 to-black/50 flex flex-col justify-center items-center text-center px-4">
            <h1 
              className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg animate-fade-in-down"
              style={{animationDelay: '0.2s'}}
            >
              Drive with Confidence
            </h1>
            <p 
              className="text-xl md:text-2xl text-white mb-8 max-w-2xl drop-shadow-md animate-fade-in-down"
              style={{animationDelay: '0.4s'}}
            >
              Experience the best car services with WeCars. Book, ride, and enjoy!
            </p>
            <button 
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg animate-fade-in-up hover:shadow-blue-500/50"
              style={{animationDelay: '0.6s'}}
            >
              Get Started
            </button>
          </div>
        </div>
      </section>

      {/* Rent Section */}
      <section id="rent" className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800 relative">
            Maintain it via <span className="text-blue-600 relative">
              3 working steps
              <span className="absolute bottom-0 left-0 w-full h-1 bg-blue-600 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300"></span>
            </span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center">
              <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 shadow-inner">
                <MapPin className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-800">Choose a location</h4>
              <p className="text-gray-600">
                Select your location from where you want your car to be picked.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center">
              <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 shadow-inner">
                <Calendar className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-800">Pick-up date</h4>
              <p className="text-gray-600 mb-4">
                Specify the date and time you wish to pick up your car.
              </p>
              <input 
                type="date" 
                value={pickupDate}
                onChange={(e) => setPickupDate(e.target.value)}
                className="border border-gray-300 rounded-md px-4 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent shadow-sm hover:shadow transition-shadow duration-200"
              />
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2 text-center">
              <div className="bg-blue-100 p-4 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-6 shadow-inner">
                <Car className="h-8 w-8 text-blue-600" />
              </div>
              <h4 className="text-xl font-semibold mb-3 text-gray-800">Book your car</h4>
              <p className="text-gray-600 mb-4">
                Finally, book the slot for your car.
              </p>
              <button className="bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-6 rounded-md transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/30 transform hover:scale-105">
                Book Now
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Service Section */}
      <section id="service" className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
            Feel the best experience with <span className="text-blue-600">our deals</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-lg group">
              <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                <Wallet className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Deals for every budget</h4>
              <p className="text-gray-600">
                From economy cars to luxury vehicles, we have services for everyone.
              </p>
            </div>
            
            <div className="p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-lg group">
              <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                <Tag className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Best price guarantee</h4>
              <p className="text-gray-600">
                Get competitive rates and book with confidence.
              </p>
            </div>
            
            <div className="p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-lg group">
              <div className="bg-blue-100 p-3 rounded-full w-12 h-12 flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-all duration-300">
                <Headset className="h-6 w-6 text-blue-600 group-hover:text-white transition-colors duration-300" />
              </div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Support 24/7</h4>
              <p className="text-gray-600">
                Our team is available 24/7 to assist you.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section id="why-choose-us" className="py-16 px-4 bg-gradient-to-r from-blue-900 to-blue-700 text-white relative overflow-hidden">
        {/* Background pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-white rounded-full"></div>
          <div className="absolute top-1/2 -right-24 w-96 h-96 bg-white rounded-full"></div>
          <div className="absolute -bottom-24 left-1/3 w-72 h-72 bg-white rounded-full"></div>
        </div>
        
        <div className="max-w-6xl mx-auto relative z-10">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Why Choose WeCars?</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-xl hover:bg-white/20 transition-colors duration-300 transform hover:scale-105">
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-2xl mr-3">🚗</span>
                  <span className="text-lg">Hassle-free booking process</span>
                </li>
                <li className="flex items-start">
                  <span className="text-2xl mr-3">🧼</span>
                  <span className="text-lg">Safe and sanitized vehicles</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm p-8 rounded-xl hover:bg-white/20 transition-colors duration-300 transform hover:scale-105">
              <ul className="space-y-4">
                <li className="flex items-start">
                  <span className="text-2xl mr-3">💰</span>
                  <span className="text-lg">Affordable pricing with no hidden charges</span>
                </li>
                <li className="flex items-start">
                  <span className="text-2xl mr-3">☎️</span>
                  <span className="text-lg">Expert customer support</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Ride Section */}
      <section id="ride" className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
            We ensure the <span className="text-blue-600">best customer experience</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 text-center group">
              <div className="text-4xl mb-4 transform group-hover:scale-110 transition-transform duration-300">🏆</div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Competitive pricing</h4>
              <p className="text-gray-600">
                We offer the best rates in the market without compromising on quality.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 text-center group">
              <div className="text-4xl mb-4 transform group-hover:scale-110 transition-transform duration-300">💳</div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Flexible Payment Plans</h4>
              <p className="text-gray-600">
                Choose from various payment options that suit your needs.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-xl shadow-md hover:shadow-xl transition-all duration-300 text-center group">
              <div className="text-4xl mb-4 transform group-hover:scale-110 transition-transform duration-300">🚦</div>
              <h4 className="text-xl font-semibold mb-2 text-gray-800 group-hover:text-blue-600 transition-colors duration-300">Roadside Assistance 24/7</h4>
              <p className="text-gray-600">
                Help is always available whenever and wherever you need it.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-gray-800">
            What Our <span className="text-blue-600">Customers Say</span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
              <div className="flex items-center mb-4">
                <div className="relative">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full blur opacity-75"></div>
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" 
                    alt="Customer 1" 
                    className="relative w-16 h-16 rounded-full object-cover border-2 border-white"
                  />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">John D.</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "WeCars made my travel easy and stress-free! The car was in perfect condition and the service was exceptional."
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
              <div className="flex items-center mb-4">
                <div className="relative">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full blur opacity-75"></div>
                  <img 
                    src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" 
                    alt="Customer 2" 
                    className="relative w-16 h-16 rounded-full object-cover border-2 border-white"
                  />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Sarah W.</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Great service, affordable prices, and excellent support! I'll definitely be using WeCars for all my future trips."
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-xl border border-gray-200 hover:border-blue-300 transition-all duration-300 hover:shadow-xl transform hover:-translate-y-1">
              <div className="flex items-center mb-4">
                <div className="relative">
                  <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-blue-400 rounded-full blur opacity-75"></div>
                  <img 
                    src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80" 
                    alt="Customer 3" 
                    className="relative w-16 h-16 rounded-full object-cover border-2 border-white"
                  />
                </div>
                <div className="ml-4">
                  <h4 className="font-semibold text-gray-800">Alex T.</h4>
                  <div className="flex text-yellow-400">
                    <span>★</span><span>★</span><span>★</span><span>★</span><span>★</span>
                  </div>
                </div>
              </div>
              <p className="text-gray-600 italic">
                "Highly recommended! Booking was seamless and hassle-free. The car was delivered on time and in excellent condition."
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact/App Download Section */}
      <section id="contact" className="py-16 px-4 bg-gradient-to-r from-blue-800 to-blue-600 text-white relative overflow-hidden">
        {/* Background elements */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10">
          <div className="absolute top-0 left-0 w-40 h-40 bg-white rounded-full transform translate-x-10 translate-y-10"></div>
          <div className="absolute bottom-0 right-0 w-60 h-60 bg-white rounded-full transform -translate-x-10 -translate-y-10"></div>
        </div>
        
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between relative z-10">
          <div className="md:w-1/2 mb-8 md:mb-0 text-center md:text-left">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Download the free WeCars app</h2>
            <p className="text-xl mb-8 text-blue-100">
              Manage bookings, find deals, and access 24/7 support from your mobile device.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center md:justify-start">
              <button className="bg-black hover:bg-gray-900 text-white font-medium py-3 px-6 rounded-lg flex items-center justify-center transition-all duration-300 transform hover:scale-105 shadow-lg">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.5,2H8.5C6.6,2,5,3.6,5,5.5v13C5,20.4,6.6,22,8.5,22h9c1.9,0,3.5-1.6,3.5-3.5v-13C21,3.6,19.4,2,17.5,2z M13,20.5h-2v-1h2V20.5z M18,17.5H8v-13h10V17.5z"/>
                </svg>
                App Store
              </button>
              <button className="bg-black hover:bg-gray-900 text-white font-medium py-3 px-6 rounded-lg flex items-center justify-center transition-all duration-300 transform hover:scale-105 shadow-lg">
                <svg className="h-6 w-6 mr-2" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3,20.5V3.5C3,2.7,3.7,2,4.5,2h15C20.3,2,21,2.7,21,3.5v17c0,0.8-0.7,1.5-1.5,1.5h-15C3.7,22,3,21.3,3,20.5z M12,17.5c0.8,0,1.5-0.7,1.5-1.5s-0.7-1.5-1.5-1.5s-1.5,0.7-1.5,1.5S11.2,17.5,12,17.5z M7.5,4.5h9v9h-9V4.5z"/>
                </svg>
                Google Play
              </button>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-purple-400 rounded-2xl blur opacity-75 animate-pulse"></div>
              <div className="relative bg-white rounded-2xl overflow-hidden shadow-2xl transform transition-transform duration-500 hover:rotate-3 hover:scale-105">
                <img 
                  src="https://images.unsplash.com/photo-1551650975-87deedd944c3?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80" 
                  alt="WeCars App" 
                  className="w-64 h-auto"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">About WeCars</h3>
              <p className="mb-4">
                Your trusted car service provider for easy and efficient vehicle management.
              </p>
              <div className="flex items-center space-x-2 mt-4 group">
                <Car className="h-6 w-6 text-blue-500 group-hover:text-blue-400 transition-colors duration-300" />
                <span className="font-bold text-xl text-white group-hover:text-blue-300 transition-colors duration-300">WeCars</span>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Contact Us</h3>
              <div className="space-y-3">
                <div className="flex items-center group">
                  <Mail className="h-5 w-5 mr-2 text-blue-500 group-hover:text-blue-400 transition-colors duration-300" />
                  <span className="group-hover:text-white transition-colors duration-300">support@wecars.com</span>
                </div>
                <div className="flex items-center group">
                  <Phone className="h-5 w-5 mr-2 text-blue-500 group-hover:text-blue-400 transition-colors duration-300" />
                  <span className="group-hover:text-white transition-colors duration-300">+1 234 567 890</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold text-lg mb-4">Follow Us</h3>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110">
                  <Facebook className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110">
                  <Twitter className="h-6 w-6" />
                </a>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-300 transform hover:scale-110">
                  <Instagram className="h-6 w-6" />
                </a>
              </div>
            </div>
          </div>
          
          <div className="pt-8 border-t border-gray-800 text-center">
            <p>Copyright © {new Date().getFullYear()} WeCars. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Scroll to top button */}
      <button 
        onClick={scrollToTop}
        className={`fixed right-6 bottom-6 p-3 rounded-full bg-blue-600 text-white shadow-lg transition-all duration-300 hover:bg-blue-700 focus:outline-none ${showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'}`}
      >
        <ChevronUp className="h-6 w-6" />
      </button>
    </div>
  );
}

export default App;